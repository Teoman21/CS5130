---
title: Business Intelligence Dashboard
emoji: 📊
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 4.44.1
app_file: app.py
pinned: false
---

## Business Intelligence Dashboard

Interactive Gradio application for exploring business datasets, generating insights, and exporting filtered results.

### Features
- Upload CSV or Excel files with automated validation and previews.
- Comprehensive statistics: numeric and categorical summaries, missing value report, correlation matrix.
- Dynamic filtering by numeric ranges, categorical selections, and date ranges with live row counts.
- Visualizations: time series, distribution, category comparisons, scatter plots, correlation heatmap.
- Automated insights: top/bottom performers, trend detection, anomaly identification.
- Export filtered data as CSV and download charts as PNG (requires `kaleido`).

### Project Structure
```
BID/
├── app.py                  # Gradio UI wiring
├── data_processor.py       # Data loading, cleaning, filtering utilities
├── visualizations.py       # Plotly chart generators
├── insights.py             # Insight extraction helpers
├── utils.py                # Shared helpers/constants
├── data/                   # Curated datasets from Kaggle & UCI
│   ├── sales_train.csv
│   ├── items.csv
│   ├── item_categories.csv
│   ├── shops.csv
│   ├── test.csv
│   └── online_retail.csv   # add this file from the UCI dataset
├── requirements.txt        # Python dependencies
└── README.md               # Project overview (this file)
```

### Sample Datasets
- Kaggle *Predict Future Sales* (`sales_train.csv` plus lookup tables `items.csv`, `item_categories.csv`, `shops.csv`).
- UCI *Online Retail* (`online_retail.csv` — place the downloaded CSV in `data/`).

Use the **Load Sample** controls on the *Data Upload* tab to bootstrap analysis with these datasets. The app augments the Kaggle sales data by joining the lookup tables automatically.

### Getting Started
1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```
   PNG exports require the optional `kaleido` dependency included above.

2. **Launch the dashboard**
   ```bash
   python app.py
   ```

3. **Load data**
   - Upload your own CSV/Excel file **or** pick one of the bundled datasets via the *Load Sample* dropdown.
   - Ensure the raw Kaggle/UCI CSV files reside in `data/` so the sample loader can detect them.

4. **Explore**
   - Apply filters, switch between visualizations, inspect automated insights, and download filtered results or charts.

### Notes
- The app infers column types automatically; ensure date columns are parseable for time-series plots and trend insights.
- Large datasets may need additional preprocessing before upload to stay within local resource limits.
